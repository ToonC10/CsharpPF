﻿namespace FLYNET;
internal class Vliegmaatschappij
{
}
