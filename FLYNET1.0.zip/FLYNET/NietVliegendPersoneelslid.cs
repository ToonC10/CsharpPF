﻿namespace FLYNET.Personeel;
public class NietVliegendPersoneelslid : Personeelslid
{
    public int UrenPerWeek { get; set; }
    public Afdeling Afdeling { get; set; }
}
