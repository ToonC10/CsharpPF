﻿//****************************************************************************************
// Certificaten
//****************************************************************************************

using FLYNET.Personeel;
using FLYNET.Vloot;

Certificaat PPL = new Certificaat
{
    CertificaatAfkorting = "PPL",
    CertificaatOmschrijving = "Private Pilot License"
};


Certificaat ATPL = new Certificaat
{
    CertificaatAfkorting = "ATPL",
    CertificaatOmschrijving = "Airline Transport Pilot License"
};

Certificaat IR = new Certificaat
{
    CertificaatAfkorting = "IR",
    CertificaatOmschrijving = "Instrument Rating"
};

Certificaat CPL = new Certificaat
{
    CertificaatAfkorting = "CPL",
    CertificaatOmschrijving = "Commercial Pilot License"
};

Certificaat ME = new Certificaat
{
    CertificaatAfkorting = "ME",
    CertificaatOmschrijving = "Multi Engine"
};

Certificaat MCC = new Certificaat
{
    CertificaatAfkorting = "MCC",
    CertificaatOmschrijving = "Multi Crew Concept"
};

Certificaat EHBO = new Certificaat
{
    CertificaatAfkorting = "EHBO",
    CertificaatOmschrijving = "First Aid"
};

Certificaat EVAC = new Certificaat
{
    CertificaatAfkorting = "EVAC",
    CertificaatOmschrijving = "Evacution Procedures"
};

Certificaat FIRE = new Certificaat
{
    CertificaatAfkorting = "FIRE",
    CertificaatOmschrijving = "Fire Fighting"
};


Certificaat SURV = new Certificaat
{
    CertificaatAfkorting = "SURV",
    CertificaatOmschrijving = "Survival"
};


Certificaat IFS = new Certificaat
{
    CertificaatAfkorting = "IFS",
    CertificaatOmschrijving = "In Flight Service"
};

// PERSONEEL

CockpitPersoneelslid cockpit1 = new()
{
    PersoneelsID = 1,
    Graad = FLYNET.Graad.Captain,
    Naam = "Captain Kirk",
    Certificaten = [PPL, ATPL, CPL, SURV],
    BasisKostPrijsPerDag = 500m,
    VliegUren = 5000
};

CockpitPersoneelslid cockpit2 = new()
{
    PersoneelsID = 2,
    Graad = FLYNET.Graad.SecondOfficer,
    Naam = "Spock",
    Certificaten = [PPL, ATPL, CPL, IFS],
    BasisKostPrijsPerDag = 400m,
    VliegUren = 4500
};

CabinePersoneelslid cabine1 = new()
{
    PersoneelsID = 3,
    Graad = FLYNET.Graad.Purser,
    Naam = "Pavel Chekov",
    Certificaten = [ME, MCC, EHBO, IFS],
    BasisKostPrijsPerDag = 300m,
    Werkpositie = "deur1"
};

CabinePersoneelslid cabine2 = new()
{
    PersoneelsID = 4,
    Graad = FLYNET.Graad.Steward,
    Naam = "Luke SkyWalker",
    Certificaten = [FIRE, SURV, IFS, EHBO],
    BasisKostPrijsPerDag = 300m,
    Werkpositie = "nooduitgang",
};

//Console.WriteLine(cockpit1.ToString());
//Console.WriteLine(cockpit2.ToString());
//Console.WriteLine(cabine1.ToString());
//Console.WriteLine(cabine2.ToString());

//VLIEGTUIGEN

Vliegtuig vliegtuig1 = new()
{
    Type = "Airbus A330-200",
    KruisSnelheid = 870,
    VliegBereik = 10800,
    BasisKostPrijsPerDag = 4000
};

Vliegtuig vliegtuig2 = new()
{
    Type = "Airbus A320",
    KruisSnelheid = 840,
    VliegBereik = 6100,
    BasisKostPrijsPerDag = 3000,
};

Vliegtuig vliegtuig3 = new()
{
    Type = "Boeing 737-800",
    KruisSnelheid = 820,
    VliegBereik = 6204,
    BasisKostPrijsPerDag = 2500,
};

Vliegtuig vliegtuig4 = new()
{
    Type = "Boeing 787-700",
    KruisSnelheid = 820,
    VliegBereik = 6370,
    BasisKostPrijsPerDag = 2000,
};

//Console.WriteLine(vliegtuig1.ToString());
//Console.WriteLine(vliegtuig2.ToString());
//Console.WriteLine(vliegtuig3.ToString());
//Console.WriteLine(vliegtuig4.ToString());