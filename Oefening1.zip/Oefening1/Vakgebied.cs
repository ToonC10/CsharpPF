﻿namespace Oefening1;
public enum Vakgebied
{
    Ontwikkeling, Netwerkbeheer
}
