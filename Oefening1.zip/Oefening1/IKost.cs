﻿namespace Oefening1;
public interface IKost
{
    public decimal Kost();
    public string Gegevens();
}