﻿namespace FLYNET;

public enum Afdeling
{
    Personeelsdienst,
    Boekhouding,
    Incheckbalie,
    Logistiek
}
public enum Graad
{
    Captain,
    SeniorFlightOfficer,
    SecondOfficer,
    JuniorFlightOfficer,
    Steward,
    Purser
}
public enum Maatschappij
{
    BrusselsAirlines,
    TUIFly,
    ASLAirlinesBelgium
}