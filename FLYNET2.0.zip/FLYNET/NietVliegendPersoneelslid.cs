﻿namespace FLYNET.Personeel;
internal class NietVliegendPersoneelslid : Personeelslid
{
    public int UrenPerWeek { get; set; }
    public Afdeling Afdeling { get; set; }
}
